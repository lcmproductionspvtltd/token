#!/bin/bash
# Builds the BQuee (customer app) app on this Mac (Android + iPhone). Works from wherever this folder is.
# First run downloads the build tools into ~/bquee-sdk (needs internet, takes a while).
HERE="$(cd "$(dirname "$0")" && pwd)"
APP="$HERE/BQuee-Customer"
OUT="$HERE/Builds"
mkdir -p "$OUT"
cd "$APP" || exit 1
START=$(date +%s)
bash tool/build_mac.sh 2>&1 | tee "$OUT/build-log.txt"
REL="$APP/build/bquee-customer-release"
if [ -f "$REL/BQuee-Customer.apk" ] && [ "$(stat -f %m "$REL/BQuee-Customer.apk")" -ge "$START" ]; then
  rm -f "$OUT"/*.apk "$OUT"/*.aab "$OUT"/*.ipa
  for f in BQuee-Customer.apk BQuee-Customer.aab BQuee-Customer-unsigned.ipa BQuee-Customer.ipa; do [ -f "$REL/$f" ] && cp "$REL/$f" "$OUT/${f/BQuee-Customer/BQuee-Customer}"; done
  echo; echo "SUCCESS – finished files are in the Builds folder"
  open "$OUT"
else
  echo; echo "BUILD FAILED – see Builds/build-log.txt"
fi
echo "You can close this window."
