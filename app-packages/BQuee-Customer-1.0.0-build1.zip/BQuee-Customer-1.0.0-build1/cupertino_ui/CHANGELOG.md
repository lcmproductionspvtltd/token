## 1.1.7

- Dims `CupertinoSlider` when disabled to match native iOS appearance.
- Fixes `CupertinoSheetRoute` throwing when a drag ends while a relayout of the sheet is pending.
- Fixes `CupertinoButton.tinted` and `CupertinoActionSheetAction`'s focus highlight filling with 12% of the accent color in light mode instead of iOS's 18%.
- Fixes `CupertinoActionSheet` semantics label not being localized.
- Fixes `NoDefaultCupertinoThemeData` equality and `hashCode` ignoring `selectionHandleColor`.

## 1.1.6

- Documents that the default background of `CupertinoSlidingSegmentedControl` is translucent.

## 1.1.5

- Fixes the installation command in README.md

## 1.1.4

- Fix CupertinoMagnifier focalPointOffset during in/out animation.

## 1.1.3

- Fixes `CupertinoPicker` throwing when it is disposed during the tap-to-select animation.

## 1.1.2

- Fixes `CupertinoMagnifier` focal point not being vertically centered when a custom `size` is used.
- Fixes unresolved doc comment references.
- Fixes `showCupertinoSheet` ignoring `showDragHandle` by forwarding it to `CupertinoSheetRoute`.

## 1.1.1

- Updates minimum supported SDK version to Flutter 3.47/Dart 3.13.

## 1.1.0

- Add `hasPlatformViews` to Cupertino sheet transitions to keep platform views synchronized with the underlying route.
- Allows `CupertinoTabBar` to contain a single item.
- Fixed some leaks of TextEditingControllers in the cupertino_ui magnifier examples.
- Fixed an issue where the `CupertinoIcons` font was not included in the cupertino_ui examples.
- Adds an option for `CupertinoPageRoute` and `CupertinoPage` to opt out of introducing a semantics route scope.
- Fixes lower routes being revealed through the top gap when multiple `CupertinoSheetRoute`s are stacked.
- Adds awaitNotRequired annotation to showCupertinoModalPopup and showCupertinoDialog.

## 1.0.1

- Add missing Widget of the Week videos to widget API docs.

## 1.0.0

- README updated for the full release of cupertino_ui.
- Promotes the pre-release to 1.0.0.
- Added a main.dart example for the Pub "Example" tab that references a curated
list of existing examples.

## 0.0.3+1

- Remove unresolvable doc import for flutter_test

## 0.0.3

- Fix API doc by clearing unsupported directives introduced by macros.
- Fix API doc references.
- Adds CupertinoUiCompatibilityBridge for legacy flutter/cupertino.dart compatibility.
- Refactors examples to not cross-import material_ui.

## 0.0.2

- Copies over all Cupertino code from flutter/flutter.
- Copies over Cupertino localizations from flutter/flutter's
  flutter_localizations package.
- Migrates API doc samples and formatting.
- Updates minimum supported SDK version to Flutter 3.44/Dart 3.12.

## 0.0.1

* Initial setup of the `cupertino_ui` package, preparing for decoupling Cupertino widgets from the Flutter framework.
