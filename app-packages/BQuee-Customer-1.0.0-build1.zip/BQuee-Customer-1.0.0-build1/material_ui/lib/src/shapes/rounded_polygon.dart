// Copyright 2013 The Flutter Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/// @docImport 'morph.dart';
library;

import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/foundation.dart';

import 'corner_rounding.dart';
import 'cubic.dart';
import 'features.dart';
import 'point.dart';
import 'utils.dart';

/// A closed polygonal shape, with optional rounding at its vertices.
///
/// A polygon can be built from a number of vertices, or from an ordered list of
/// vertices.
@immutable
final class RoundedPolygon {
  /// Creates a regular polygon with [numVertices] vertices, equally spaced
  /// around a circle of the given [radius] about [center].
  ///
  /// The default radius of 1 puts the vertices on the unit circle, giving a
  /// shape 2 wide and 2 high, which will usually need [normalized] to fit the
  /// unit square a shape border expects.
  ///
  /// [rounding] rounds every vertex the same way. [perVertexRounding]
  /// overrides it, and must have [numVertices] elements when it is not null.
  /// The default leaves the corners sharp and the edges straight.
  ///
  /// Throws [ArgumentError] if [numVertices] is less than 3, or if
  /// [perVertexRounding] has the wrong number of elements.
  factory RoundedPolygon(
    int numVertices, {
    double radius = 1,
    Offset center = Offset.zero,
    CornerRounding rounding = CornerRounding.unrounded,
    List<CornerRounding>? perVertexRounding,
  }) {
    if (numVertices < 3) {
      throw ArgumentError('numVertices must be at least 3.');
    }

    return RoundedPolygon.fromVertices(
      _verticesFromNumVerts(numVertices, radius, center),
      rounding: rounding,
      perVertexRounding: perVertexRounding,
      center: center,
    );
  }

  RoundedPolygon._raw(List<PolygonFeature> features, Point center)
    : _features = List<PolygonFeature>.unmodifiable(features),
      _center = center,
      _cubics = List<CubicBezier>.unmodifiable(_buildCubics(features, center)) {
    CubicBezier prevCubic = _cubics.last;

    for (final CubicBezier cubic in _cubics) {
      if ((cubic.anchor0X - prevCubic.anchor1X).abs() > distanceEpsilon ||
          (cubic.anchor0Y - prevCubic.anchor1Y).abs() > distanceEpsilon) {
        throw ArgumentError(
          'RoundedPolygon must be contiguous, with the anchor points of all '
          'curves matching the anchor points of the preceding and succeeding '
          'cubics.',
        );
      }
      prevCubic = cubic;
    }
  }

  /// Creates a polygon with the given [vertices].
  ///
  /// The list must be ordered: the outline runs from each vertex to the next
  /// and closes from the last back to the first. Any other order gives
  /// undefined results.
  ///
  /// [rounding] rounds every vertex the same way. [perVertexRounding]
  /// overrides it, and must have the same length as [vertices] when it is not
  /// null. The default leaves the corners sharp and the edges straight.
  ///
  /// [center] defaults to the average of [vertices].
  ///
  /// Throws [ArgumentError] if [vertices] has fewer than 3 elements, or if
  /// [perVertexRounding] has the wrong number of elements.
  factory RoundedPolygon.fromVertices(
    List<Offset> vertices, {
    CornerRounding rounding = CornerRounding.unrounded,
    List<CornerRounding>? perVertexRounding,
    Offset? center,
  }) {
    if (vertices.length < 3) {
      throw ArgumentError('Polygons must have at least 3 vertices.');
    }
    if (perVertexRounding != null && perVertexRounding.length != vertices.length) {
      throw ArgumentError(
        'perVertexRounding list should be either null or '
        'the same size as the number of vertices.',
      );
    }
    final corners = <List<CubicBezier>>[];
    final int n = vertices.length;
    final roundedCorners = <_RoundedCorner>[];
    for (var i = 0; i < n; i++) {
      final CornerRounding vtxRounding = perVertexRounding?[i] ?? rounding;
      final int prevIndex = (i + n - 1) % n;
      final int nextIndex = (i + 1) % n;
      roundedCorners.add(
        _RoundedCorner(vertices[prevIndex], vertices[i], vertices[nextIndex], vtxRounding),
      );
    }

    // For each side, check if we have enough space to do the cuts needed, and
    // if not split the available space, first for round cuts, then for
    // smoothing if there is space left. Each element in this list is a pair,
    // that represent how much we can do of the cut for the given side (side i
    // goes from corner i to corner i+1), the elements of the pair are: first
    // is how much we can use of expectedRoundCut, second how much of
    // expectedCut.
    final List<(double, double)> cutAdjusts = List.generate(n, (ix) {
      final double expectedRoundCut =
          roundedCorners[ix].expectedRoundCut + roundedCorners[(ix + 1) % n].expectedRoundCut;
      final double expectedCut =
          roundedCorners[ix].expectedCut + roundedCorners[(ix + 1) % n].expectedCut;
      final Point vtx = vertices[ix];
      final Point nextVtx = vertices[(ix + 1) % n];
      final double sideSize = (vtx - nextVtx).distance;

      // Check expectedRoundCut first, and ensure we fulfill rounding needs
      // first for both corners before using space for smoothing.
      if (expectedRoundCut > sideSize) {
        // Not enough room for fully rounding, see how much we can actually do.
        return (sideSize / expectedRoundCut, 0.0);
      } else if (expectedCut > sideSize) {
        // We can do full rounding, but not full smoothing.
        return (1.0, (sideSize - expectedRoundCut) / (expectedCut - expectedRoundCut));
      } else {
        // There is enough room for rounding & smoothing.
        return (1.0, 1.0);
      }
    });

    // Create and store list of beziers for each [potentially] rounded corner.
    for (var i = 0; i < n; i++) {
      // allowedCuts[0] is for the side from the previous corner to this one,
      // allowedCuts[1] is for the side from this corner to the next one.
      final allowedCuts = List<double>.filled(2, 0);

      for (var delta = 0; delta <= 1; delta++) {
        final (double roundCutRatio, double cutRatio) = cutAdjusts[(i + n - 1 + delta) % n];
        allowedCuts[delta] =
            roundedCorners[i].expectedRoundCut * roundCutRatio +
            (roundedCorners[i].expectedCut - roundedCorners[i].expectedRoundCut) * cutRatio;
      }

      corners.add(roundedCorners[i].getCubics(allowedCuts[0], allowedCuts[1]));
    }

    // Finally, store the calculated cubics. This includes all of the rounded
    // corners from above, along with new cubics representing the edges between
    // those corners.
    final tempFeatures = <PolygonFeature>[];
    for (var i = 0; i < n; i++) {
      final Point currVertex = vertices[i];
      final Point prevVertex = vertices[(i + n - 1) % n];
      final Point nextVertex = vertices[(i + 1) % n];
      final bool cvx = convex(prevVertex, currVertex, nextVertex);
      tempFeatures
        ..add(CornerFeature(corners[i], convex: cvx))
        ..add(
          EdgeFeature([
            CubicBezier.straightLine(corners[i].last.anchor1, corners[(i + 1) % n].first.anchor0),
          ]),
        );
    }

    return RoundedPolygonInternals.fromFeatures(
      tempFeatures,
      center: center ?? calculateCenter(vertices),
    );
  }

  /// Creates a circle of the given [radius] about [center], approximated by
  /// rounding a polygon of [numVertices] vertices.
  ///
  /// Throws [ArgumentError] if [numVertices] is less than 3.
  factory RoundedPolygon.circle({
    int numVertices = 8,
    double radius = 1,
    Offset center = Offset.zero,
  }) {
    if (numVertices < 3) {
      throw ArgumentError('Circle must have at least three vertices.');
    }

    // Half of the angle between two adjacent vertices on the polygon.
    final double theta = math.pi / numVertices;
    // Radius of the underlying RoundedPolygon object given the desired radius
    // of the circle.
    final double polygonRadius = radius / math.cos(theta);
    return RoundedPolygon(
      numVertices,
      radius: polygonRadius,
      center: center,
      rounding: CornerRounding(radius: radius),
    );
  }

  /// Creates a rectangle [width] wide and [height] high about [center], with
  /// optional rounding at its four corners.
  ///
  /// The default dimensions and center fit the shape into the 2x2 box around
  /// the origin, which will usually need [normalized] to fit the unit square a
  /// shape border expects.
  ///
  /// [rounding] rounds all four corners the same way. [perVertexRounding]
  /// overrides it, and must have 4 elements when it is not null. The default
  /// leaves the corners sharp.
  ///
  /// Throws [ArgumentError] if either [width] or [height] is not greater
  /// than 0.
  factory RoundedPolygon.rectangle({
    double width = 2,
    double height = 2,
    CornerRounding rounding = CornerRounding.unrounded,
    List<CornerRounding>? perVertexRounding,
    Offset center = Offset.zero,
  }) {
    if (width <= 0 || height <= 0) {
      throw ArgumentError('Rectangles must have positive width and height.');
    }

    final double left = center.x - width / 2;
    final double top = center.y - height / 2;
    final double right = center.x + width / 2;
    final double bottom = center.y + height / 2;

    return RoundedPolygon.fromVertices(
      [Point(right, bottom), Point(left, bottom), Point(left, top), Point(right, top)],
      rounding: rounding,
      perVertexRounding: perVertexRounding,
      center: center,
    );
  }

  /// Creates a star about [center], with [numVerticesPerRadius] vertices on
  /// the outer [radius] alternating with as many on the [innerRadius].
  ///
  /// Both radii must be greater than 0, and [innerRadius] must be less than
  /// [radius].
  ///
  /// [rounding] rounds every vertex the same way. [innerRounding] overrides it
  /// for the vertices on [innerRadius]. [perVertexRounding] overrides both,
  /// and must have 2 * [numVerticesPerRadius] elements when it is not null,
  /// alternating outer and inner starting with an outer vertex. The default
  /// leaves the corners sharp and the edges straight.
  ///
  /// Throws [ArgumentError] if [numVerticesPerRadius] is less than 3, if
  /// either radius is not greater than 0, if [innerRadius] is not less than
  /// [radius], or if [perVertexRounding] has the wrong number of elements.
  factory RoundedPolygon.star({
    required int numVerticesPerRadius,
    double radius = 1,
    double innerRadius = 0.5,
    CornerRounding rounding = CornerRounding.unrounded,
    CornerRounding? innerRounding,
    List<CornerRounding>? perVertexRounding,
    Offset center = Offset.zero,
  }) {
    if (numVerticesPerRadius < 3) {
      throw ArgumentError('numVerticesPerRadius must be at least 3.');
    }
    if (radius <= 0 || innerRadius <= 0) {
      throw ArgumentError('Star radii must both be greater than 0.');
    }
    if (innerRadius >= radius) {
      throw ArgumentError('innerRadius must be less than radius.');
    }

    var pvRounding = perVertexRounding;
    // If no per-vertex rounding supplied and caller asked for inner rounding,
    // create per-vertex rounding list based on supplied outer/inner rounding
    // parameters.
    if (pvRounding == null && innerRounding != null) {
      pvRounding = [
        for (var i = 0; i < numVerticesPerRadius; i++) ...[rounding, innerRounding],
      ];
    }

    // Star polygon is just a polygon with all vertices supplied (where we
    // generate those vertices to be on the inner/outer radii).
    return RoundedPolygon.fromVertices(
      _starVerticesFromNumVerts(numVerticesPerRadius, radius, innerRadius, center),
      rounding: rounding,
      perVertexRounding: pvRounding,
      center: center,
    );
  }

  /// Creates a pill about [center], [width] wide and [height] high: a
  /// rectangle capped by a semicircle at either end of its longer dimension.
  ///
  /// [smoothing] extends the curve from the circular arc of each cap towards
  /// the edge between the two caps. The default of 0 leaves the caps as
  /// circular arcs.
  ///
  /// Throws [ArgumentError] if either [width] or [height] is not greater
  /// than 0.
  factory RoundedPolygon.pill({
    double width = 2,
    double height = 1,
    double smoothing = 0,
    Offset center = Offset.zero,
  }) {
    if (width <= 0 || height <= 0) {
      throw ArgumentError('Pill shapes must have positive width and height.');
    }

    final double wHalf = width / 2;
    final double hHalf = height / 2;

    return RoundedPolygon.fromVertices(
      [
        Point(wHalf + center.x, hHalf + center.y),
        Point(-wHalf + center.x, hHalf + center.y),
        Point(-wHalf + center.x, -hHalf + center.y),
        Point(wHalf + center.x, -hHalf + center.y),
      ],
      rounding: CornerRounding(radius: math.min(wHalf, hHalf), smoothing: smoothing),
      center: center,
    );
  }

  /// Creates a pill star about [center], [width] wide and [height] high: a
  /// [RoundedPolygon.pill] with inner and outer radii along its outline, the
  /// way a [RoundedPolygon.star] has them along a circle, with
  /// [numVerticesPerRadius] vertices on each.
  ///
  /// [innerRadiusRatio] gives the inner radius as a fraction of the outer one.
  /// It must be greater than 0 and no greater than 1, and a value of 1 gives a
  /// pill with more vertices than [RoundedPolygon.pill] would produce.
  ///
  /// [rounding] rounds every vertex the same way. [innerRounding] overrides it
  /// for the inner vertices. [perVertexRounding] overrides both, and must have
  /// 2 * [numVerticesPerRadius] elements when it is not null.
  ///
  /// How the two sets of vertices proceed along the curved ends is subtler
  /// than on a star, because of the curvature there: outer vertices lying
  /// along the curved outline force the inner ones closer together, while
  /// inner vertices lying along it force the outer ones further apart.
  /// [vertexSpacing] chooses between those extremes. A value of 0 spaces the
  /// inner vertices as they are spaced along the straight edges, 1 does the
  /// same for the outer vertices, and the default of 0.5 averages the two, so
  /// that each set falls equally to either side of the pill outline. Which
  /// value suits a shape depends on its rounding and radius parameters.
  ///
  /// [startLocation] is how far along the perimeter the outline's curves
  /// begin, from 0 to 1. This is rarely needed or noticed, but it decides
  /// where the path starts and ends for a caller stroking it gradually.
  ///
  /// Throws [ArgumentError] if [numVerticesPerRadius] is less than 3, if
  /// either [width] or [height] is not greater than 0, if [innerRadiusRatio]
  /// is outside the range 0 (exclusive) to 1, or if [vertexSpacing] or
  /// [startLocation] is outside the range 0 to 1.
  factory RoundedPolygon.pillStar({
    double width = 2,
    double height = 1,
    int numVerticesPerRadius = 8,
    double innerRadiusRatio = 0.5,
    CornerRounding rounding = CornerRounding.unrounded,
    CornerRounding? innerRounding,
    List<CornerRounding>? perVertexRounding,
    double vertexSpacing = 0.5,
    double startLocation = 0,
    Offset center = Offset.zero,
  }) {
    if (numVerticesPerRadius < 3) {
      throw ArgumentError('numVerticesPerRadius must be at least 3.');
    }
    if (width <= 0 || height <= 0) {
      throw ArgumentError('Pill shapes must have positive width and height.');
    }
    if (innerRadiusRatio <= 0 || innerRadiusRatio > 1) {
      throw ArgumentError('innerRadiusRatio must be in (0, 1] range.');
    }
    if (vertexSpacing < 0 || vertexSpacing > 1) {
      throw ArgumentError('vertexSpacing must be in [0, 1] range.');
    }
    if (startLocation < 0 || startLocation > 1) {
      throw ArgumentError('startLocation must be in [0, 1] range.');
    }

    var pvRounding = perVertexRounding;
    // If no per-vertex rounding supplied and caller asked for inner rounding,
    // create per-vertex rounding list based on supplied outer/inner rounding
    // parameters.
    if (pvRounding == null && innerRounding != null) {
      pvRounding = [
        for (var i = 0; i < numVerticesPerRadius; i++) ...[rounding, innerRounding],
      ];
    }

    return RoundedPolygon.fromVertices(
      _pillStarVerticesFromNumVerts(
        numVerticesPerRadius,
        width,
        height,
        innerRadiusRatio,
        vertexSpacing,
        startLocation,
        center,
      ),
      rounding: rounding,
      perVertexRounding: pvRounding,
      center: center,
    );
  }

  final List<PolygonFeature> _features;

  final Point _center;

  final List<CubicBezier> _cubics;

  static List<CubicBezier> _buildCubics(List<PolygonFeature> features, Point center) {
    final cubics = <CubicBezier>[];

    // The first/last mechanism here ensures that the final anchor point in the
    // shape exactly matches the first anchor point. There can be rendering
    // artifacts introduced by those points being slightly off, even by much
    // less than a pixel.
    CubicBezier? firstCubic;
    CubicBezier? lastCubic;
    List<CubicBezier>? firstFeatureSplitStart;
    List<CubicBezier>? firstFeatureSplitEnd;

    if (features.isNotEmpty && features[0].cubics.length == 3) {
      final CubicBezier centerCubic = features[0].cubics[1];
      final (CubicBezier start, CubicBezier end) = centerCubic.split(0.5);
      firstFeatureSplitStart = [features[0].cubics[0], start];
      firstFeatureSplitEnd = [end, features[0].cubics[2]];
    }

    // iterating one past the features list size allows us to insert the
    // initial split cubic if it exists.
    for (var i = 0; i <= features.length; i++) {
      final List<CubicBezier> featureCubics;

      if (i == 0 && firstFeatureSplitEnd != null) {
        featureCubics = firstFeatureSplitEnd;
      } else if (i == features.length) {
        if (firstFeatureSplitStart != null) {
          featureCubics = firstFeatureSplitStart;
        } else {
          break;
        }
      } else {
        featureCubics = features[i].cubics;
      }

      for (var j = 0; j < featureCubics.length; j++) {
        // Skip zero-length curves; they add nothing and can trigger rendering
        // artifacts.
        final CubicBezier cubic = featureCubics[j];

        if (!cubic.isZeroLength) {
          if (lastCubic != null) {
            cubics.add(lastCubic);
          }
          lastCubic = cubic;
          firstCubic ??= cubic;
        } else {
          if (lastCubic != null) {
            // Dropping several zero-ish length curves in a row can lead to
            // enough discontinuity to throw an exception later, even though the
            // distances are quite small. Account for that by making the last
            // cubic use the latest anchor point, always.
            lastCubic = CubicBezier.raw(
              lastCubic.anchor0X,
              lastCubic.anchor0Y,
              lastCubic.control0X,
              lastCubic.control0Y,
              lastCubic.control1X,
              lastCubic.control1Y,
              cubic.anchor1X,
              cubic.anchor1Y,
            );
          }
        }
      }
    }

    if (lastCubic != null && firstCubic != null) {
      cubics.add(
        CubicBezier.raw(
          lastCubic.anchor0X,
          lastCubic.anchor0Y,
          lastCubic.control0X,
          lastCubic.control0Y,
          lastCubic.control1X,
          lastCubic.control1Y,
          firstCubic.anchor0X,
          firstCubic.anchor0Y,
        ),
      );
    } else {
      // Empty / 0-sized polygon.
      cubics.add(CubicBezier.point(center));
    }

    return cubics;
  }

  /// Returns a new [RoundedPolygon], moving and resizing this one, so it's
  /// completely inside the (0, 0) -> (1, 1) square, centered if there is extra
  /// space in one direction.
  RoundedPolygon normalized() {
    final Rect bounds = calculateApproximateBounds();
    final double side = math.max(bounds.width, bounds.height);

    if (side < distanceEpsilon) {
      return this;
    }

    // Center the shape if bounds are not a square.
    final double offsetX = (side - bounds.width) / 2 - bounds.left;
    final double offsetY = (side - bounds.height) / 2 - bounds.top;

    return transformed((x, y) => ((x + offsetX) / side, (y + offsetY) / side));
  }

  @override
  String toString() {
    return '${objectRuntimeType(this, 'RoundedPolygon')}'
        '(center: $_center, features: ${_features.length}, cubics: ${_cubics.length})';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }

    return other is RoundedPolygon &&
        other._center == _center &&
        listEquals(other._features, _features);
  }

  @override
  late final int hashCode = Object.hash(_center, Object.hashAll(_features));
}

/// Members of [RoundedPolygon] that are not part of the public API.
extension RoundedPolygonInternals on RoundedPolygon {
  /// Creates a polygon from [features], which describe each segment of its
  /// outline.
  ///
  /// Specifying the features directly controls precisely how the polygon's
  /// [CubicBezier]s are grouped into curves, and it is those groups that
  /// [Morph] maps: it pairs each curve with one of the same type in the other
  /// shape, convex with convex and concave with concave.
  ///
  /// [center] defaults to the average of every cubic's starting anchor point.
  ///
  /// Throws [ArgumentError] if [features] has fewer than 2 elements, or if the
  /// features don't describe a closed shape.
  static RoundedPolygon fromFeatures(List<PolygonFeature> features, {Offset? center}) {
    if (features.length < 2) {
      throw ArgumentError('Polygons must have at least 2 features.');
    }

    if (center != null) {
      return RoundedPolygon._raw(features, center);
    }

    final vertices = <Point>[];

    for (final feature in features) {
      for (final CubicBezier cubic in feature.cubics) {
        vertices.add(Point(cubic.anchor0X, cubic.anchor0Y));
      }
    }

    return RoundedPolygon._raw(features, calculateCenter(vertices));
  }

  /// The [PolygonFeature]s this polygon is composed of.
  ///
  /// This list is unmodifiable.
  List<PolygonFeature> get features => _features;

  /// A flattened version of the [PolygonFeature]s, as a `List<CubicBezier>`.
  ///
  /// This list is unmodifiable.
  List<CubicBezier> get cubics => _cubics;

  /// The center of this polygon, around which all vertices are placed.
  Offset get center => _center;

  /// Returns a new [RoundedPolygon] with every point of this one, including
  /// its [center], mapped through [transformer].
  RoundedPolygon transformed(ShapePointTransformer transformer) {
    return RoundedPolygon._raw([
      for (var i = 0; i < _features.length; i++) _features[i].transformed(transformer),
    ], _center.transformed(transformer));
  }

  /// Like [calculateBounds], calculates the axis-aligned bounds of this shape,
  /// but determines the max dimension of the shape (by calculating the
  /// distance from its center to the start and midpoint of each curve) and
  /// returns a square which can be used to hold the object in any rotation.
  ///
  /// This can be used, for example, to calculate the max size of a UI element
  /// meant to hold this shape in any rotation.
  Rect calculateMaxBounds() {
    var maxDistSquared = 0.0;
    for (var i = 0; i < _cubics.length; i++) {
      final CubicBezier cubic = _cubics[i];
      final double anchorDistance = (cubic.anchor0 - _center).distanceSquared;
      final Point middlePoint = cubic.pointAt(0.5);
      final double middleDistance = (middlePoint - _center).distanceSquared;
      maxDistSquared = math.max(maxDistSquared, math.max(anchorDistance, middleDistance));
    }

    final double distance = math.sqrt(maxDistSquared);

    return Rect.fromLTRB(
      _center.x - distance,
      _center.y - distance,
      _center.x + distance,
      _center.y + distance,
    );
  }

  /// Calculates the axis-aligned bounds of this shape.
  ///
  /// This solves for the actual extrema of every curve. See
  /// [calculateApproximateBounds] for a cheaper result that is never smaller
  /// than this one.
  Rect calculateBounds() => _computeBounds(approximate: false);

  /// A cheaper alternative to [calculateBounds], based on the min/max values of
  /// all anchor and control points that make up this shape.
  ///
  /// The result is never smaller than [calculateBounds], but can be larger.
  Rect calculateApproximateBounds() => _computeBounds(approximate: true);

  Rect _computeBounds({required bool approximate}) {
    Rect bounds = approximate
        ? _cubics.first.calculateApproximateBounds()
        : _cubics.first.calculateBounds();

    for (var i = 1; i < _cubics.length; i++) {
      final CubicBezier cubic = _cubics[i];
      bounds = bounds.expandToInclude(
        approximate ? cubic.calculateApproximateBounds() : cubic.calculateBounds(),
      );
    }

    return bounds;
  }

  /// Returns a [Path] for this polygon.
  ///
  /// [startAngle] places the start point of the polygon's first curve at that
  /// angle, in radians, around the polygon's [center], rotating the polygon
  /// about that center to get it there. Zero is to the right of the center and
  /// `pi / 2` below it, since y grows downwards.
  /// The default of zero is special: it skips the rotation entirely and leaves
  /// the polygon as it was built.
  ///
  /// If [repeatPath] is true, the curves are added twice before the [Path] is
  /// closed. This is useful when the caller would like to draw parts of the
  /// path while offsetting the start and stop positions, for example when
  /// phasing and rotating a path to simulate motion as a star-shaped circular
  /// progress indicator advances.
  ///
  /// If [closePath] is false, the returned [Path] is left open.
  Path toPath({double startAngle = 0, bool repeatPath = false, bool closePath = true}) {
    return pathFromCubics(
      _cubics,
      startAngle: startAngle,
      repeatPath: repeatPath,
      closePath: closePath,
      rotationPivot: _center,
    );
  }
}

/// Calculates an estimated center position for the polygon, returning it. This
/// function should only be called if the center is not already calculated or
/// provided. The Polygon constructor which takes `numVertices` calculates its
/// own center, since it knows exactly where it is centered, at (0, 0).
///
/// Note that this center will be transformed whenever the shape itself is
/// transformed. Any transforms that occur before the center is calculated will
/// be taken into account automatically since the center calculation is an
/// average of the current location of all cubic anchor points.
@internal
Point calculateCenter(List<Point> vertices) {
  var cumulativeX = 0.0;
  var cumulativeY = 0.0;
  for (final vertex in vertices) {
    cumulativeX += vertex.x;
    cumulativeY += vertex.y;
  }
  return Point(cumulativeX / vertices.length, cumulativeY / vertices.length);
}

/// The geometry of a single corner of a polygon, rounded according to
/// [rounding].
///
/// [p0], [p1] and [p2] are three consecutive vertices of the polygon, [p1]
/// being the one this corner rounds. [getCubics] returns the curves that
/// describe the rounded corner.
///
/// If [rounding] is null there is no rounding, and the corner is a single
/// point at [p1], represented by a [CubicBezier] of length 0 there.
///
/// If [rounding] is not null the corner is rounded with a curve approximating
/// a circular arc of the radius it specifies, or with three curves if it also
/// has a nonzero smoothing parameter: a circular arc in the middle and two
/// symmetrical flanking curves on either side, whose curvature the smoothing
/// parameter determines.
///
/// This is a class because the work usually happens in two steps, with state
/// to keep between them: first we determine how much we want to cut to comply
/// with the parameters, then we are given how much we can actually cut,
/// because of space restrictions outside this corner.
class _RoundedCorner {
  _RoundedCorner(this.p0, this.p1, this.p2, this.rounding) {
    final Point v01 = p0 - p1;
    final Point v21 = p2 - p1;
    final double d01 = v01.distance;
    final double d21 = v21.distance;

    if (d01 > 0 && d21 > 0) {
      d1 = v01 / d01;
      d2 = v21 / d21;
      cornerRadius = rounding?.radius ?? 0;
      smoothing = rounding?.smoothing ?? 0;

      // cosine of angle at p1 is dot product of unit vectors to the other
      // two vertices.
      cosAngle = d1.dotProduct(d2);

      // identity: sin^2 + cos^2 = 1
      // sinAngle gives us the intersection
      sinAngle = math.sqrt(1 - square(cosAngle));

      // How much we need to cut, as measured on a side, to get the required
      // radius calculating where the rounding circle hits the edge.
      // This uses the identity of tan(A/2) = sinA/(1 + cosA), where
      // tan(A/2) = radius/cut.
      expectedRoundCut = (sinAngle > 1e-3) ? cornerRadius * (cosAngle + 1) / sinAngle : 0;
    } else {
      // One (or both) of the sides is empty, not much we can do.
      d1 = Point.zero;
      d2 = Point.zero;
      cornerRadius = 0;
      smoothing = 0;
      cosAngle = 0;
      sinAngle = 0;
      expectedRoundCut = 0;
    }
  }

  final Point p0;

  final Point p1;

  final Point p2;

  final CornerRounding? rounding;

  late final Point d1;

  late final Point d2;

  late final double cornerRadius;

  late final double smoothing;

  late final double cosAngle;

  late final double sinAngle;

  late final double expectedRoundCut;

  // Smoothing changes the actual cut. 0 is same as expectedRoundCut, 1
  // doubles it.
  double get expectedCut => (1 + smoothing) * expectedRoundCut;

  /// The center of the circle approximated by the rounding curve, or by the
  /// middle of the three curves if smoothing is requested.
  ///
  /// This is [p1] itself if there is no rounding.
  Point center = Point.zero;

  List<CubicBezier> getCubics(double allowedCut0, double allowedCut1) {
    // We use the minimum of both cuts to determine the radius, but if there is
    // more space in one side we can use it for smoothing.
    final double allowedCut = math.min(allowedCut0, allowedCut1);

    // Nothing to do, just use lines, or a point
    if (expectedRoundCut < distanceEpsilon ||
        allowedCut < distanceEpsilon ||
        cornerRadius < distanceEpsilon) {
      center = p1;
      return [CubicBezier.straightLine(p1, p1)];
    }

    // How much of the cut is required for the rounding part.
    final double actualRoundCut = math.min(allowedCut, expectedRoundCut);

    // We have two smoothing values, one for each side of the vertex
    // Space is used for rounding values first. If there is space left over,
    // then we apply smoothing, if it was requested
    final double actualSmoothing0 = _calculateActualSmoothingValue(allowedCut0);
    final double actualSmoothing1 = _calculateActualSmoothingValue(allowedCut1);
    // Scale the radius if needed
    final double actualR = cornerRadius * actualRoundCut / expectedRoundCut;
    // Distance from the corner (p1) to the center
    final double centerDistance = math.sqrt(square(actualR) + square(actualRoundCut));
    // Center of the arc we will use for rounding
    center = p1 + ((d1 + d2) / 2).unitVector * centerDistance;
    final Point circleIntersection0 = p1 + d1 * actualRoundCut;
    final Point circleIntersection2 = p1 + d2 * actualRoundCut;
    final CubicBezier flanking0 = _computeFlankingCurve(
      actualRoundCut,
      actualSmoothing0,
      p1,
      p0,
      circleIntersection0,
      circleIntersection2,
      center,
      actualR,
    );
    final CubicBezier flanking2 = _computeFlankingCurve(
      actualRoundCut,
      actualSmoothing1,
      p1,
      p2,
      circleIntersection2,
      circleIntersection0,
      center,
      actualR,
    ).reversed;

    return [
      flanking0,
      CubicBezier.circularArc(center, flanking0.anchor1, flanking2.anchor0),
      flanking2,
    ];
  }

  /// If [allowedCut] (the amount we are able to cut) is greater than the
  /// expected cut (without smoothing applied yet), then there is room to apply
  /// smoothing and we calculate the actual smoothing value here.
  double _calculateActualSmoothingValue(double allowedCut) {
    if (allowedCut > expectedCut) {
      return smoothing;
    } else if (allowedCut > expectedRoundCut) {
      return smoothing * (allowedCut - expectedRoundCut) / (expectedCut - expectedRoundCut);
    } else {
      return 0;
    }
  }

  /// Returns a [CubicBezier] smoothly connecting the linear side running from
  /// [sideStart] to [corner] with the circular segment of radius [actualR]
  /// about [circleCenter], starting on the linear side and ending on the
  /// circular segment.
  ///
  /// [actualRoundCut] is how much of the corner we are cutting to add the
  /// circular segment, before smoothing cuts any more, and
  /// [actualSmoothingValues] is how much we want to smooth: the smoothing
  /// parameter, adjusted down if there is not enough room.
  ///
  /// [circleSegmentIntersection] is where the linear side and the circle
  /// intersect, and [otherCircleSegmentIntersection] is where the opposing
  /// side and the circle do.
  CubicBezier _computeFlankingCurve(
    double actualRoundCut,
    double actualSmoothingValues,
    Point corner,
    Point sideStart,
    Point circleSegmentIntersection,
    Point otherCircleSegmentIntersection,
    Point circleCenter,
    double actualR,
  ) {
    // sideStart is the anchor, 'anchor' is actual control point
    final Point sideDirection = (sideStart - corner).unitVector;
    final Point curveStart = corner + sideDirection * actualRoundCut * (1 + actualSmoothingValues);

    // We use an approximation to cut a part of the circle section proportional
    // to 1 - smooth, When smooth = 0, we take the full section, when
    // smooth = 1, we take nothing.
    final Point p = interpolate(
      circleSegmentIntersection,
      (circleSegmentIntersection + otherCircleSegmentIntersection) / 2,
      actualSmoothingValues,
    );

    // The flanking curve ends on the circle
    final Point curveEnd = circleCenter + (p - circleCenter).unitVector * actualR;

    // The anchor on the circle segment side is in the intersection between the
    // tangent to the circle in the circle/flanking curve boundary and the
    // linear segment.
    final Point circleTangent = (curveEnd - circleCenter).rotate90();
    final Point anchorEnd =
        _lineIntersection(sideStart, sideDirection, curveEnd, circleTangent) ??
        circleSegmentIntersection;

    // From what remains, we pick a point for the start anchor.
    // 2/3 seems to come from design tools?
    final Point anchorStart = (curveStart + anchorEnd * 2) / 3;

    return CubicBezier(curveStart, anchorStart, anchorEnd, curveEnd);
  }

  /// Returns the point where the line through [p0] in direction [d0] meets the
  /// line through [p1] in direction [d1], or null if the two do not intersect.
  Point? _lineIntersection(Point p0, Point d0, Point p1, Point d1) {
    final Point rotatedD1 = d1.rotate90();
    final double den = d0.dotProduct(rotatedD1);

    if (den.abs() < distanceEpsilon) {
      return null;
    }

    final double num = (p1 - p0).dotProduct(rotatedD1);

    // Also check the relative value. This is equivalent to
    // (den/num).abs() < distanceEpsilon, but avoid doing a division
    if (den.abs() < distanceEpsilon * num.abs()) {
      return null;
    }

    final double k = num / den;
    return p0 + d0 * k;
  }
}

List<Point> _verticesFromNumVerts(int numVertices, double radius, Point center) {
  return List<Point>.generate(
    numVertices,
    (i) => radialToCartesian(radius, math.pi / numVertices * 2 * i) + center,
  );
}

List<Point> _pillStarVerticesFromNumVerts(
  int numVerticesPerRadius,
  double width,
  double height,
  double innerRadius,
  double vertexSpacing,
  double startLocation,
  Point center,
) {
  // The general approach here is to get the perimeter of the underlying pill
  // outline, then the t value for each vertex as we walk that perimeter. This
  // tells us where on the outline to place that vertex, then we figure out
  // where to place the vertex depending on which "section" it is in. The
  // possible sections are the vertical edges on the sides, the circular
  // sections on all four corners, or the horizontal edges on the top and
  // bottom. Note that either the vertical or horizontal edges will be of
  // length zero (whichever dimension is smaller gets only circular curvature
  // for the pill shape).
  final double endcapRadius = math.min(width, height);
  final double vSegLen = math.max(height - width, 0.0);
  final double hSegLen = math.max(width - height, 0.0);
  final double vSegHalf = vSegLen / 2;
  final double hSegHalf = hSegLen / 2;
  // vertexSpacing is used to position the vertices on the end caps. The caller
  // has the choice of spacing the inner (0) or outer (1) vertices like those
  // along the edges, causing the other vertices to be either further apart (0)
  // or closer (1). The default is .5, which averages things. The magnitude of
  // the inner and rounding parameters may cause the caller to want a different
  // value.
  final double circlePerimeter = math.pi * 2 * endcapRadius * lerp(innerRadius, 1, vertexSpacing);
  // perimeter is circle perimeter plus horizontal and vertical sections of
  // inner rectangle, whether either (or even both) might be of length zero.
  final double perimeter = 2 * hSegLen + 2 * vSegLen + circlePerimeter;

  // The sections array holds the t start values of that part of the outline.
  // We use these to determine which section a given vertex lies in, based on
  // it's t value, as well as where in that section it lies.
  final sections = List<double>.filled(11, 0);
  sections[0] = 0;
  sections[1] = vSegLen / 2;
  sections[2] = sections[1] + circlePerimeter / 4;
  sections[3] = sections[2] + hSegLen;
  sections[4] = sections[3] + circlePerimeter / 4;
  sections[5] = sections[4] + vSegLen;
  sections[6] = sections[5] + circlePerimeter / 4;
  sections[7] = sections[6] + hSegLen;
  sections[8] = sections[7] + circlePerimeter / 4;
  sections[9] = sections[8] + vSegLen / 2;
  sections[10] = perimeter;

  // "t" is the length along the entire pill outline for a given vertex. With
  // vertices spaced evenly along this contour, we can determine for any vertex
  // where it should lie.
  final double tPerVertex = perimeter / (2 * numVerticesPerRadius);
  // separate iteration for inner vs outer, unlike the other shapes, because
  // the vertices can lie in different quadrants so each needs their own
  // calculation.
  var inner = false;
  // Increment section index as we walk around the pill contour with our
  // increasing t values.
  var currSecIndex = 0;
  // secStart/End are used to determine how far along a given vertex is in the
  // section in which it lands.
  var secStart = 0.0;
  double secEnd = sections[1];
  // t value is used to place each vertex. 0 is on the positive x axis,
  // moving into section 0 to begin with. startLocation, a value from 0 to 1,
  // varies the location anywhere on the perimeter of the shape.
  double t = startLocation * perimeter;
  // The list of vertices to be returned.
  final result = List<Point>.filled(numVerticesPerRadius * 2, Point.zero);
  final rectBR = Point(hSegHalf, vSegHalf);
  final rectBL = Point(-hSegHalf, vSegHalf);
  final rectTL = Point(-hSegHalf, -vSegHalf);
  final rectTR = Point(hSegHalf, -vSegHalf);

  // Each iteration through this loop uses the next t value as we walk around
  // the shape.
  for (var i = 0; i < numVerticesPerRadius * 2; i++) {
    // t could start (and end) after 0; extra boundedT logic makes sure it does
    // the right thing when crossing the boundary past 0 again.
    final double boundedT = t % perimeter;
    if (boundedT < secStart) {
      currSecIndex = 0;
      secStart = 0;
      secEnd = sections[1];
    }
    while (boundedT >= sections[(currSecIndex + 1) % sections.length]) {
      currSecIndex = (currSecIndex + 1) % sections.length;
      secStart = sections[currSecIndex];
      secEnd = sections[(currSecIndex + 1) % sections.length];
    }

    // find t in section and its proportion of that section's total length
    final double tInSection = boundedT - secStart;
    final double tProportion = tInSection / (secEnd - secStart);

    // The vertex placement in a section varies depending on whether it is on
    // one of the semicircle endcaps or along one of the straight edges. For
    // the endcaps, we use tProportion to get the angle along that circular cap
    // and add the starting angle for that section. For the edges we use a
    // straight linear calculation given tProportion and the start/end t values
    // for that edge.
    final double currRadius = inner ? (endcapRadius * innerRadius) : endcapRadius;
    final Point vertex = switch (currSecIndex) {
      0 => Point(currRadius, tProportion * vSegHalf),
      1 => radialToCartesian(currRadius, tProportion * math.pi / 2) + rectBR,
      2 => Point(hSegHalf - tProportion * hSegLen, currRadius),
      3 => radialToCartesian(currRadius, math.pi / 2 + (tProportion * math.pi / 2)) + rectBL,
      4 => Point(-currRadius, vSegHalf - tProportion * vSegLen),
      5 => radialToCartesian(currRadius, math.pi + (tProportion * math.pi / 2)) + rectTL,
      6 => Point(-hSegHalf + tProportion * hSegLen, -currRadius),
      7 => radialToCartesian(currRadius, math.pi * 1.5 + (tProportion * math.pi / 2)) + rectTR,
      // 8
      _ => Point(currRadius, -vSegHalf + tProportion * vSegHalf),
    };
    result[i] = vertex + center;
    t += tPerVertex;
    inner = !inner;
  }

  return result;
}

List<Point> _starVerticesFromNumVerts(
  int numVerticesPerRadius,
  double radius,
  double innerRadius,
  Point center,
) {
  final result = List<Point>.filled(numVerticesPerRadius * 2, Point.zero);
  var arrayIndex = 0;

  for (var i = 0; i < numVerticesPerRadius; i++) {
    result[arrayIndex++] =
        radialToCartesian(radius, math.pi / numVerticesPerRadius * 2 * i) + center;
    result[arrayIndex++] =
        radialToCartesian(innerRadius, math.pi / numVerticesPerRadius * (2 * i + 1)) + center;
  }

  return result;
}
