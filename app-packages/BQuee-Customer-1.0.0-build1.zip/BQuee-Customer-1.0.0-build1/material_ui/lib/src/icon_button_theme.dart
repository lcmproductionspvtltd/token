// Copyright 2013 The Flutter Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/// @docImport 'icon_button.dart';
library;

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

import 'button_style.dart';
import 'theme.dart';
import 'theme_data.dart';

// Examples can assume:
// late BuildContext context;

/// A [ButtonStyle] that overrides the default appearance of
/// [IconButton]s when it's used with the [IconButton], the [IconButtonTheme] or the
/// overall [Theme]'s [ThemeData.iconButtonTheme].
///
/// The [IconButton] will be affected by [IconButtonTheme] and [IconButtonThemeData]
/// only if [ThemeData.useMaterial3] is set to true; otherwise, [IconTheme] will be used.
///
/// The [style]'s properties override [IconButton]'s default style. Only
/// the style's non-null property values or resolved non-null
/// [WidgetStateProperty] values are used.
///
/// See also:
///
///  * [IconButtonTheme], the theme which is configured with this class.
///  * [IconButton.styleFrom], which converts simple values into a
///    [ButtonStyle] that's consistent with [IconButton]'s defaults.
///  * [WidgetStateProperty.resolve], "resolve" a material state property
///    to a simple value based on a set of [WidgetState]s.
///  * [ThemeData.iconButtonTheme], which can be used to override the default
///    [ButtonStyle] for [IconButton]s below the overall [Theme].
@immutable
class IconButtonThemeData with Diagnosticable {
  /// Creates a [IconButtonThemeData].
  ///
  /// The [style] may be null.
  const IconButtonThemeData({this.style, this.variant});

  /// Overrides for [IconButton]'s default style if [ThemeData.useMaterial3]
  /// is set to true.
  ///
  /// Non-null properties or non-null resolved [WidgetStateProperty]
  /// values override the default [ButtonStyle] in [IconButton].
  ///
  /// If [style] is null, then this theme doesn't override anything.
  final ButtonStyle? style;

  /// The style variant of Material Design used by [IconButton].
  ///
  /// Set this to [StyleVariant.material3Expressive] to opt icon buttons into
  /// the Material 3 Expressive style.
  ///
  /// If null, the variant is inherited from the closest enclosing
  /// [IconButtonTheme] that specifies one, and then from
  /// [ThemeData.iconButtonTheme]. If none of them specify a variant,
  /// [IconButton] uses [StyleVariant.material3]. To keep a subtree on
  /// Material 3 when an ancestor opts into Material 3 Expressive, set this to
  /// [StyleVariant.material3].
  ///
  /// An enclosing [IconButtonTheme] takes precedence over
  /// [ThemeData.iconButtonTheme], even when a closer [Theme] specifies a
  /// different variant. This matches [IconButtonTheme.of], which only uses
  /// [ThemeData.iconButtonTheme] when there is no enclosing [IconButtonTheme].
  /// To change the variant of a subtree, wrap it in an [IconButtonTheme].
  ///
  /// See also:
  ///
  ///  * [IconButtonTheme.variantOf], which returns the variant that applies
  ///    at a given location.
  final StyleVariant? variant;

  /// Linearly interpolate between two icon button themes.
  static IconButtonThemeData? lerp(IconButtonThemeData? a, IconButtonThemeData? b, double t) {
    if (identical(a, b)) {
      return a;
    }
    return IconButtonThemeData(
      style: ButtonStyle.lerp(a?.style, b?.style, t),
      variant: t < 0.5 ? a?.variant : b?.variant,
    );
  }

  @override
  int get hashCode => Object.hash(style, variant);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other.runtimeType != runtimeType) {
      return false;
    }
    return other is IconButtonThemeData && other.style == style && other.variant == variant;
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty<ButtonStyle>('style', style, defaultValue: null));
    properties.add(EnumProperty<StyleVariant>('variant', variant, defaultValue: null));
  }
}

/// Overrides the default [ButtonStyle] of its [IconButton] descendants.
///
/// See also:
///
///  * [IconButtonThemeData], which is used to configure this theme.
///  * [IconButton.styleFrom], which converts simple values into a
///    [ButtonStyle] that's consistent with [IconButton]'s defaults.
///  * [ThemeData.iconButtonTheme], which can be used to override the default
///    [ButtonStyle] for [IconButton]s below the overall [Theme].
class IconButtonTheme extends InheritedTheme {
  /// Create a [IconButtonTheme].
  const IconButtonTheme({super.key, required this.data, required super.child});

  /// The configuration of this theme.
  final IconButtonThemeData data;

  /// Retrieves the [IconButtonThemeData] from the closest ancestor [IconButtonTheme].
  ///
  /// If there is no enclosing [IconButtonTheme] widget, then
  /// [ThemeData.iconButtonTheme] is used.
  ///
  /// The returned [IconButtonThemeData.variant] is the value specified by
  /// that theme, which can be null even when an ancestor specifies a variant.
  /// Use [variantOf] to get the variant that applies at the given [context].
  ///
  /// Typical usage is as follows:
  ///
  /// ```dart
  /// IconButtonThemeData theme = IconButtonTheme.of(context);
  /// ```
  static IconButtonThemeData of(BuildContext context) {
    final IconButtonTheme? buttonTheme = context
        .dependOnInheritedWidgetOfExactType<IconButtonTheme>();
    return buttonTheme?.data ?? Theme.of(context).iconButtonTheme;
  }

  /// Returns the [StyleVariant] that [IconButton]s use at the given [context].
  ///
  /// The closest enclosing [IconButtonTheme] whose
  /// [IconButtonThemeData.variant] is non-null determines the variant, so an
  /// [IconButtonTheme] that doesn't specify a variant inherits it from its
  /// ancestors. If none of the enclosing [IconButtonTheme]s specify a variant,
  /// the variant of [ThemeData.iconButtonTheme] is used. If that is also null,
  /// [StyleVariant.material3] is returned.
  ///
  /// Typical usage is as follows:
  ///
  /// ```dart
  /// final StyleVariant variant = IconButtonTheme.variantOf(context);
  /// ```
  static StyleVariant variantOf(BuildContext context) {
    InheritedElement? element = context.getElementForInheritedWidgetOfExactType<IconButtonTheme>();
    while (element != null) {
      // Depend on every theme that is visited, so that a change to any of them
      // rebuilds the dependent.
      context.dependOnInheritedElement(element);
      final StyleVariant? variant = (element.widget as IconButtonTheme).data.variant;
      if (variant != null) {
        return variant;
      }
      // Calling getElementForInheritedWidgetOfExactType on the element itself
      // would return the same element, so continue the search from its parent.
      Element? parent;
      element.visitAncestorElements((Element ancestor) {
        parent = ancestor;
        return false;
      });
      element = parent?.getElementForInheritedWidgetOfExactType<IconButtonTheme>();
    }
    return Theme.of(context).iconButtonTheme.variant ?? StyleVariant.material3;
  }

  @override
  Widget wrap(BuildContext context, Widget child) {
    return IconButtonTheme(data: data, child: child);
  }

  @override
  bool updateShouldNotify(IconButtonTheme oldWidget) => data != oldWidget.data;
}
