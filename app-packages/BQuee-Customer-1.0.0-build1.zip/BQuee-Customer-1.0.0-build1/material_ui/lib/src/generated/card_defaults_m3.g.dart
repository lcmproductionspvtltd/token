// Copyright 2013 The Flutter Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Do not edit by hand. The code is generated from data in the Material
// Design token database by the script:
//   packages/material_ui/tool/gen_defaults/bin/gen_defaults.dart.
part of '../card.dart';

class _CardDefaultsM3 extends CardThemeData {
  _CardDefaultsM3(this.context)
    : super(clipBehavior: Clip.none, elevation: 1.0, margin: const EdgeInsets.all(4.0));

  final BuildContext context;
  late final ColorScheme _colors = Theme.of(context).colorScheme;

  @override
  Color? get color => _colors.surfaceContainerLow;

  @override
  Color? get shadowColor => _colors.shadow;

  @override
  Color? get surfaceTintColor => Colors.transparent;

  @override
  ShapeBorder? get shape =>
      const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(12.0)));
}
