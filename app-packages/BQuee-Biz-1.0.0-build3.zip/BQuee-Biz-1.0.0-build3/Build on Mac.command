#!/bin/bash
# Builds the BQuee Biz app on this Mac (Android + iPhone). Works from wherever this folder is.
# First run downloads the build tools into ~/bquee-sdk (needs internet, takes a while).
HERE="$(cd "$(dirname "$0")" && pwd)"
APP="$HERE/BQuee-Biz"
OUT="$HERE/Builds"
mkdir -p "$OUT"
cd "$APP" || exit 1
START=$(date +%s)
bash tool/build_mac.sh 2>&1 | tee "$OUT/build-log.txt"
REL="$APP/build/bquee-release"
if [ -f "$REL/BQuee.apk" ] && [ "$(stat -f %m "$REL/BQuee.apk")" -ge "$START" ]; then
  rm -f "$OUT"/*.apk "$OUT"/*.aab "$OUT"/*.ipa
  for f in BQuee.apk BQuee.aab BQuee-unsigned.ipa BQuee.ipa; do [ -f "$REL/$f" ] && cp "$REL/$f" "$OUT/${f/BQuee/BQuee-Biz}"; done
  echo; echo "SUCCESS – finished files are in the Builds folder"
  open "$OUT"
else
  echo; echo "BUILD FAILED – see Builds/build-log.txt"
fi
echo "You can close this window."
